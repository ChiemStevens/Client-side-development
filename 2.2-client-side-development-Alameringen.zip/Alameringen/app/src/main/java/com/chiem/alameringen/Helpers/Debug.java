package com.chiem.alameringen.Helpers;

public class Debug {

    public static final String TAG = "Alarmeringen";

}
